package com.letterbook.interaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InteractionApplicationTests {

    @Test
    void contextLoads() {
    }

}
