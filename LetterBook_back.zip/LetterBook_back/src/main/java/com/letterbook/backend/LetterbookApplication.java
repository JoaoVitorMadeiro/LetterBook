package com.letterbook.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.session.autoconfigure.SessionAutoConfiguration;

@SpringBootApplication(exclude = {SessionAutoConfiguration.class})
public class LetterbookApplication {

    public static void main(String[] args) {
        SpringApplication.run(LetterbookApplication.class, args);
    }

}
