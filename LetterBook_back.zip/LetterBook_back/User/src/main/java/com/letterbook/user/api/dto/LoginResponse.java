package com.letterbook.user.api.dto;

public record LoginResponse(String token) {
}
