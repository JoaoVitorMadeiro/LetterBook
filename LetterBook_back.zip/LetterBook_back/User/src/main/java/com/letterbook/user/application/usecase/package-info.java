@org.springframework.modulith.NamedInterface("usecase")
package com.letterbook.user.application.usecase;


