package com.letterbook.user.api.dto;

public record UserLoginRequest() {
    static String username;
    static String password;

}