@org.springframework.modulith.NamedInterface("model")
package com.letterbook.user.domain.model;


