@org.springframework.modulith.NamedInterface("repository")
package com.letterbook.user.domain.repository;


